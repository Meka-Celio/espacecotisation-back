<!DOCTYPE html>
<html>
<head>
	<meta charset="utf8">
	<meta name="viewport" content="width=devicewidth, initialscale=1">
	<title>Filtre sur année</title>
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
</head>
<body>

    <form action="#">
        <label for="">2021</label>
        <input type="checkbox" aria-details="4">
        <label for="">2020</label>
        <input type="checkbox" aria-details="3">
        <label for="">2019</label>
        <input type="checkbox" aria-details="2">
        <label for="">2018</label>
        <input type="checkbox" aria-details="1">
    </form>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.js"
        integrity="sha512-n/4gHW3atM3QqRcbCn6ewmpxcLAHGaDjpEBu4xZd47N0W2oQ+6q7oc3PXstrJYXcbNU1OHdQ1T7pAP+gi5Yu8g=="
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</script>
<script src="box.js"></script>
</body>
</html>